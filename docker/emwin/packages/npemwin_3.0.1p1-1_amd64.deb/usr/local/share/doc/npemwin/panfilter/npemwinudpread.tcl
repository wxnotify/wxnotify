#!/usr/bin/tclsh8.6
#
# Copyright (c) 2008 Jose F. Nieves <nieves@ltp.upr.clu.edu>
#
# See LICENSE
#
# $Id: dda657c23874142fa5f4dedc16320ca8d42dfb1e $
#
# This is meant to an example of a program that receives PAN messages
# from the panfilter via udp on port 5000.
#
# It requires the tcludp package.

package require udp;

proc read_message {f} {

    set msg [read $f];

    set peer [fconfigure $f -peer];
    set remoteip [lindex $peer 0];

    # puts $msg
    set mlist [split $msg];

    set wmoid [lindex $mlist 0];
    set wmostation [lindex $mlist 1];
    set wmotime [lindex $mlist 2];
    set awips [lindex $mlist 3];
    set fbasename [lindex $mlist 4];

    puts "From $remoteip: $wmoid $fbasename";

#   For text files
#    set F [open "|curl -s -S http://$remoteip:8015/_get/spool/$fbasename"];
#    fconfigure $F -encoding binary -translation binary;
#    read $F 24;
#    set data [read $F];
#    close $F;
#    puts [string map {\r ""} $data];
}

set s [udp_open 5000];
fconfigure $s -buffering none -translation binary -encoding binary;

fileevent $s readable [list read_message $s];
set done 0;
vwait done;

close $s;
