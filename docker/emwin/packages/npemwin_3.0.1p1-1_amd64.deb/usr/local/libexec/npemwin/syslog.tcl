#
# $Id: 6c7bb0916fd5bdc463a6a870eadcb135104288ed $
#
package provide npemwin::syslog 1.0;

package require npemwin::errx;
::npemwin::syslog::usesyslog;
