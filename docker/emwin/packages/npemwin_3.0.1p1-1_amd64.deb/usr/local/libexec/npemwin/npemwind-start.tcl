#
# $Id: 2b82d0f02381aa81224d67af90ada0c527abf44e $
#
# This script is not run by tclsh but instead it is evaluated directly
# by the server in a tcl interp.
#
exec "/usr/local/libexec/npemwin/startstop" "start";
