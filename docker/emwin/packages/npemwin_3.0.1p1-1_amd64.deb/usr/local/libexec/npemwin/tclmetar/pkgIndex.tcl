#
# $Id: f9ffdbc42824edf4f932ef5ea6ecdddd93e92328 $
#
package ifneeded metar 1.0 [list source [file join $dir metar.tcl]]
