#
# $Id: 235fb4a9cf6721314cc2980dc1dc48ba2574af09 $
#
package ifneeded npemwin::errx 1.0 \
    [list source [file join $dir errx.tcl]]

package ifneeded npemwin::syslog 1.0 \
    [list source [file join $dir syslog.tcl]]
