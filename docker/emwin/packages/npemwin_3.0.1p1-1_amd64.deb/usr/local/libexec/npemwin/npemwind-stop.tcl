#
# $Id: 74fa6bd223a7ef3b6d204e086177325515e5ba48 $
#
# This script is not run by tclsh but instead it is evaluated directly
# by the server in a tcl interp.
#
exec "/usr/local/libexec/npemwin/startstop" "stop";
